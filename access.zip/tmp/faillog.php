<?php
/*
Login attempts info.
*/
$login_faillog = array (
  0 => 
  array (
    '186.155.209.49' => 0,
    'last' => '',
  ),
  1 => 
  array (
    '186.147.33.65' => 0,
    'last' => '',
  ),
  2 => 
  array (
    '186.155.209.49' => 0,
    'last' => '',
  ),
  3 => 
  array (
    '186.155.209.49' => 0,
    'last' => '',
  ),
);
